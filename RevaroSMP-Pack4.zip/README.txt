Revaro Custom Items Resource Pack 1.1.0

Neu:
- Polizeifunk
- Dienstmarke
- Leerer Beweisbeutel
- Versiegelter Beweisbeutel
- Werttransport-Koffer

Enthält weiterhin:
- RevaroPhone
- Bargeld
- Police/Crime Cuffs + Keys
- Edelsteine

Das Pack verändert keine normalen Vanilla-Item-Texturen.
